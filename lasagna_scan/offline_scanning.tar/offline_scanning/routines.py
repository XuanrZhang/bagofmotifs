import urllib
import urllib2
import json
import os
import gzip
import numpy
import string
import sys

class modelPSSM:
    pass

def ConvertModel(dictModel):
    model = modelPSSM()
    model.acc = dictModel['acc']
    model.name = dictModel['name']
    model.l = dictModel['l']
    model.scores = numpy.array(dictModel['scores'])
    model.scores_2mer = dictModel['scores_2mer']
    model.SCOPE = dictModel['K']
    model.alphabet = dictModel['alphabet']
    model.n = dictModel['n']
    model.score_dist = numpy.array(dictModel['score_dist'], dtype = numpy.float)
    return model

def FetchModelAccs(species=None):
    url = 'http://biogrid.engr.uconn.edu/lasagna_search/get_tfs.php'
    if isinstance(species, str): url += '?species=' + urllib.quote(species)
    inp = urllib2.urlopen(url)
    accs = json.load(inp)
    inp.close()
    return accs

def FetchNSaveModels(db, accs, folder):
    if not os.path.exists(folder):
        os.makedirs(folder)
    url = 'http://biogrid.engr.uconn.edu/lasagna_search/get_models.php?db=%s&accs[]=%s'\
          % (urllib.quote(db), '&accs[]='.join(map(urllib.quote, accs)))
    inp = urllib2.urlopen(url)
    models = json.loads(str(inp.read()))
    inp.close()
    paths = []
    for acc in accs:
        path = '%s/%s_%s.json.gz' % (folder, db, acc)
        paths.append(path)
        out = gzip.open(path, 'w')
        json.dump(models[acc], out)
        out.close()
    return paths

## modelPath: model file in JSON
def LoadModel(modelPath, convert = True):
    inp = gzip.open(modelPath, 'r') if modelPath.endswith('.gz')\
          else open(modelPath, 'r')
    model = json.loads(str(inp.read()))
    inp.close()
    if convert:
        model = ConvertModel(model)
    return model

# complement base
complement = string.maketrans('acgtACGT-', 'tgcaTGCA-')
def ReverseComplement(s):
    return s[::-1].translate(complement)

def ScoreByPSSM(seq, model, jStart, cache = None):
    seq = seq.lower()
    seqKey = seq + str(jStart)
    if (cache != None) and (seqKey in cache):
        return cache[seqKey]
    l = len(seq)
    score = 0.0
    for i in xrange(l):
        if seq[i] in model.scores[jStart + i]:
            s = model.scores[jStart + i][seq[i]]
        else:
            s = min( model.scores[jStart + i].values() )
            model.scores[jStart + i][seq[i]] = s
        score += s
    for scope in xrange(1, model.SCOPE + 1):
        for i in xrange(l - scope):
            p = seq[i] + seq[i + scope]
            if p in model.scores_2mer[scope - 1][jStart + i]:
                s = model.scores_2mer[scope - 1][jStart + i][p]
            else:
                s = min( model.scores_2mer[scope - 1][jStart + i].values() )
                model.scores_2mer[scope - 1][jStart + i][p] = s
            score += s
    if cache != None:
        try:
            cache[seqKey] = score
        except MemoryError:
            cache.clear()
            cache[seqKey] = score
        except:
            raise
    return score

## Slide seq through the PSSM
## Return the maximal score and the matched positions of the sequence and PSSM 
def SlideScoreByPSSM(seq, model, cache = None, cache2 = None):
    seq = seq.lower()
    if cache2 != None and seq in cache2:
        return cache2[seq]
    seqL = len(seq)
    bestScore = None
    jStart = 0 # first position of the PSSM
    for iStart in xrange(seqL - 1, -1, -1): # last letter of the sequence
        subseqL = min(seqL - iStart, model.l)
        subseq = seq[iStart:(iStart + subseqL)]
        subseq = subseq + '-' * (model.l - subseqL)
        score = ScoreByPSSM(subseq, model, 0, cache = cache)
        if bestScore is None or score > bestScore:
            bestScore = score
            bestAlign = (iStart, jStart)
    for jStart in xrange(1, model.l):
        subseqL = min(model.l - jStart, seqL)
        subseq = seq[:subseqL]
        subseq = '-' * jStart + subseq + '-' * (model.l - subseqL - jStart)
        score = ScoreByPSSM(subseq, model, 0, cache = cache)
        if bestScore is None or score > bestScore:
            bestScore = score
            bestAlign = (iStart, jStart)
    if cache2 != None:
        try:
            cache2[seq] = (bestScore, bestAlign)
        except MemoryError:
            cache2.clear()
            cache2[seq] = (bestScore, bestAlign)
        except:
            raise
    return bestScore, bestAlign

##l: lenght of the PSSM
##seqL: length of the putative site
##start: position of the first base of the putative site
##align: (iStart, jStart) describes how the putative site aligns with the PSSM
##       iStart: first base of the putative site, jStart: first base of the PSSM in the alignment
def FindPosLen(l, seqL, start, strand, align):
    iStart, jStart = align
    if jStart == 0:
        subseqL = min(seqL - iStart, l)
        if strand == '+':
            pos = start + iStart
        else: # strand == '-'
            # (start + seqL - 1) - subseqL + 1
            pos = start + seqL - iStart - subseqL
    else: # iStart == 0
        subseqL = min(l - jStart, seqL)
        if strand == '+':
            pos = start
        else: # strand == '-'
            # (start + seqL - 1) - subseqL + 1
            pos = start + seqL - subseqL
    return pos, subseqL

def ComputePvalues(scores, model):
    pvalues = numpy.zeros(len(scores), dtype = float)
    topN = len(model.score_dist)
    cnt = 0
    j = 0
    for i in numpy.argsort(scores)[::-1]:
        score = scores[i]
        while j < topN and score < model.score_dist[j]:
            cnt += 1
            j += 1
        pvalues[i] = float(cnt) / model.n
    return pvalues

## Search seq for variable-length binding sites by PSSM
## pvalue: compute pvalue?
## cache: sequence score cache for a model used by ScoreByPSSM()
def SearchByPSSMVarLen(seq, model, l, pvalue = False, cache = None, cache2 = None):
    seqL = len(seq)
    scores = numpy.zeros(seqL - l + 1, dtype = float)
    strands = numpy.ones(seqL - l + 1, dtype = bool) # True for '+' strand, False for '-' strand
    poss = numpy.zeros(seqL - l + 1, dtype = int)
    subseqLs = numpy.zeros(seqL - l + 1, dtype = int)
    for i in xrange(seqL - l + 1):
        s = seq[i:(i+l)]; s_rc = ReverseComplement(s)
        score1, align = SlideScoreByPSSM(s, model, cache = cache)
        pos1, subseqL1 = FindPosLen(model.l, l, i, '+', align)
        score2, align = SlideScoreByPSSM(s_rc, model, cache = cache)
        pos2, subseqL2 = FindPosLen(model.l, l, i, '-', align)
        if score1 >= score2: # positive strand
            scores[i], strands[i], poss[i], subseqLs[i] = score1, True, pos1, subseqL1
        else:
            scores[i], strands[i], poss[i], subseqLs[i] = score2, False, pos2, subseqL2
    pvalues = ComputePvalues(scores, model) if pvalue else None
    return scores, strands, poss, subseqLs, pvalues

def ReadSeq(inp):
    line = inp.readline()
    while line and not line.strip(): # skip empty lines
        line = inp.readline()
    if not line:
        return None, None
    header = line[1:].strip() if line[0] == '>' else line.strip()
    seq = inp.readline().strip()
    letter = inp.read(1)
    while letter and letter != '>':
        seq += (letter + inp.readline().strip())
        letter = inp.read(1)
    return header, seq

# header: a fasta header in UCSC promoter files
#         E.g., NM_032291_up_1000_chr1_66998825_f chr1:66998825-66999824
#         start (<= end), end are 1-based and inclusive
def GetGenomicRange(header):
    tmp = header.split()
    strand = '+' if tmp[0][-1] == 'f' else '-'
    chrom, startEnd = tmp[-1].split(':')
    start, end = map(long, startEnd.split('-'))
    return chrom, strand, start, end

## topHits contains sorted hits by score
def UpdateTopHits(topHits, topN, hit):
    chrom, chromStart, chromEnd, strand, score = hit
    found = False; i = 0
    for i in xrange(len(topHits)):
        if score > topHits[i][-1] or\
           (score == topHits[i][-1] and\
            (chrom, chromStart, chromEnd) < topHits[i][:-2]):
            found = True
            break
    if found:
        if not( i > 0 and topHits[i-1][:-2] == hit[:-2]): # Check for redundant hit
            topHits.insert(i, hit)
    else:
        if not (len(topHits) and topHits[-1][:-2] == hit[:-2]): # Check for redundant hit
            topHits.append(hit)
    del topHits[topN:]
    # True when topHits initially contains topN hits and hit is appended to the end of topHits
    return (not found) and i == (topN - 1)

def ScanUCSCPromoters(params):
    if params.topN != None:
        topHits = []
    model = LoadModel(params.modelPath, convert=True)
    # Read fasta file
    fastaInp = gzip.open(params.fastaPath, 'r')\
               if params.fastaPath.endswith('.gz') else\
                  open(params.fastaPath, 'r')
    # Open hit file
    out = gzip.open(params.outPath, 'w') if params.outPath.endswith('.gz') \
          else open(params.outPath, 'w')
    if params.pvalueThres is not None:
        print >>out, '\t'.join(['Chrom', 'Start', 'End', 'Strand', 'Score', 'p-value'])
    else:
        print >>out, '\t'.join(['Chrom', 'Start', 'End', 'Strand', 'Score'])
    rangeByChrom = {}
    cache = {}
    cache2 = {}
    seqCnt = 0
    header, seq = True, True
    while header != None and seq != None:
        header, seq = ReadSeq(fastaInp)
        if header == None or seq == None:
            break
        if seqCnt % 10:
            cache = {}; cache2 = {}
        print >>sys.stderr, header
        seqL = len(seq)
        seqChrom, seqStrand, seqStart, seqEnd = GetGenomicRange(header) # start, end are 1-based and inclusive
        if params.ignoreRandomUnmappedChrom:
            chrN = seqChrom[3:]
            if chrN.find('Un') == 0 or chrN.find('random') != -1 or chrN.find('_') != -1:
                print >>sys.stderr, '\tIgnored!'
                continue
        if not seqChrom in rangeByChrom:
            rangeByChrom[seqChrom] = {}
        if (seqStart, seqEnd) in rangeByChrom[seqChrom]: # skip redundant sequence
            print >>sys.stderr, '\tRedundant. Skipped!'
            continue
        else:
            rangeByChrom[seqChrom][(seqStart, seqEnd)] = True
        seqCnt += 1
        scores, strands, poss, subseqLs, pvalues = SearchByPSSMVarLen(
            seq, model, model.l, pvalue = params.computePvalue,
            cache = cache, cache2 = cache2)
        hits = {}
        if seqStrand == '+':
            for i in xrange(len(scores)):
                if params.pvalueThres != None and pvalues[i] > params.pvalueThres:
                    continue
                start = poss[i] + seqStart - 1 # 0-based inclusive
                end = start + subseqLs[i] # 0-based exclusive
                strand = '+' if strands[i] else '-'
                if not (start in hits):
                    hits[start] = (scores[i], None if pvalues is None else pvalues[i], start, end, strand)
                elif scores[i] > hits[start][0]:
                    hits[start] = (scores[i], None if pvalues is None else pvalues[i], start, end, strand)
        else: # seqStrand == '-'
            for i in xrange(len(scores)):
                if params.pvalueThres != None and pvalues[i] > params.pvalueThres:
                    continue
                end = seqEnd - poss[i] # 0-based exclusive
                start = end - subseqLs[i] # 0-based inclusive
                strand = '-' if strands[i] else '+'
                if not (end in hits):
                    hits[end] = (scores[i], None if pvalues is None else pvalues[i], start, end, strand)
                elif scores[i] > hits[end][0]:
                    hits[end] = (scores[i], None if pvalues is None else pvalues[i], start, end, strand)
        hits = hits.values()
        hits.sort(reverse=True)
        if params.pvalueThres is not None:
            for score, pvalue, start, end, strand in hits:
                print >>out, '%s\t%s\t%s\t%s\t%s\t%s' % (seqChrom, start, end, strand, score, pvalue)
            out.flush()
        else:
            for score, pvalue, start, end, strand in hits:
                if UpdateTopHits(topHits, params.topN, (seqChrom, start, end, strand, score)):
                    break
    fastaInp.close()
    if params.topN != None:
        topHits.sort()
        for hit in topHits:
            print >>out, '\t'.join(map(str, hit))
    out.close()






