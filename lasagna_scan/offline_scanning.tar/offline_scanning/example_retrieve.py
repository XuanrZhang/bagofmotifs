from routines import *

# Fetch all Vertebrate accessions
accsList = FetchModelAccs(species='Vertebrates')
## print accsList # To see the structure of accsList
db = accsList[0]['db']; acc = accsList[0]['tfs'][0]['acc'] # The first model
# Fetch the first model and save in the current working directory
paths = FetchNSaveModels(db, [acc], './')

# To retrieve all the models
##accsList = FetchModelAccs()
##for accs in accsList:
##    db = accs['db']
##    for tf in accs['tfs']:
##        acc = tf['acc']
##        paths = FetchNSaveModels(db, [acc], './' + db)



