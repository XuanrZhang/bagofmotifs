===================
example_retrieve.py
===================
An example script for retrieving TF models from LASAGNA-Search.

To retrieve all the models*, uncomment the second part of the script.

*A model contains log odds of nucleotides and nucleotide pairs. The original
alignments or count/probability matrices cannot be obtained from model files.


======================
scan_UCSC_promoters.py
======================
usage: scan_UCSC_promoters.py [-h] [--pvalue p] [--top N] [--compute-pvalue]
                              [--ignore-unmapped]
                              model seqs hits

Scan UCSC Genome Browser promoters by a LASAGNA-Search model

positional arguments:
  model              path to model file in JSON
  seqs               path to sequence file in fasta*
  hits               path to hit file**

optional arguments:
  -h, --help         show this help message and exit
  --pvalue p         p-value cutoff
  --top N            report only N highest scoring hits
  --compute-pvalue   compute p-value for each hit
  --ignore-unmapped  ignore sequences on random/unmapped chromosomes

*Fasta headers must be formatted as follows:
name_[fr] chrom:chromStart-chromEnd
E.g.,
NM_018090_up_1000_chr1_16766167_f chr1:16766167-16767166
NM_032785_up_1000_chr1_50489627_r chr1:50489627-50490626
The human (hg19) promoter sequences at the UCSC Genome Browser are in this
format:
ftp://hgdownload.cse.ucsc.edu/goldenPath/hg19/bigZips/upstream1000.fa.gz

**Output format:
Tab-delimited
Fields: Chrom, Start, End, Strand, Score[, p-value]
  Start: 0-based, inclusive
  End: 0-based, exclusive

