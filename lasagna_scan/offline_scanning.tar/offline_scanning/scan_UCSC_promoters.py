import argparse
from routines import ScanUCSCPromoters

def CreateArgumentParser():
    parser = argparse.ArgumentParser(
        description='Scan UCSC Genome Browser promoters by a LASAGNA-Search model')
    parser.add_argument('modelPath', metavar='model', type=str,
                   help='path to model file in JSON')
    parser.add_argument('fastaPath', metavar='seqs', type=str,
                   help='path to sequence file in fasta')
    parser.add_argument('outPath', metavar='hits', type=str,
                   help='path to hit file')
    parser.add_argument('--pvalue', metavar='p', dest='pvalueThres',
                        type=float, default=None, help='p-value cutoff')
    parser.add_argument('--top', metavar='N', dest='topN', type=int,
                        default=1000, help='report only N highest scoring hits')
    parser.add_argument('--compute-pvalue', action='store_const',
                        dest='computePvalue', default=False, const=True,
                        help='compute p-value for each hit')
    parser.add_argument('--ignore-unmapped', action='store_const',
                        dest='ignoreRandomUnmappedChrom', default=False, const=True,
                        help='ignore sequences on random/unmapped chromosomes')
    return parser

def ParseArgs():
    arg_parser = CreateArgumentParser()
    params = arg_parser.parse_args()
    if params.pvalueThres != None:
        params.computePvalue = True
    return params

if __name__ == '__main__':
    params = ParseArgs()
    ScanUCSCPromoters(params)
